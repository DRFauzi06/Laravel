<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leony's Blog</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-dc2NSrAXbAkjrdm9IYrX10fQq9SDG6Vjz7nQVKdKcJl3pC+k37e7qJR5MVSCS+wR" crossorigin="anonymous">
    

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
</head>
<body> 
    
    
	
    <div class="container-sm ">
        
            <h2 class="text-center text-dark mt-5">Sign In Form</h2>
            
            <div class="card my-5 ">
    
              <form class="card-body cardbody-color p-lg-5" action="/registerup" method="POST">
                <?php echo csrf_field(); ?>
    
                <div class="text-center">
                  <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                    width="200px" alt="profile">
                </div>
    
                <div class="mb-3">
                  <input type="text" class="form-control" id="username" aria-describedby="emailHelp"
                    placeholder="Username" name="name">
                </div>
                <div class="mb-3">
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp"
                      placeholder="Email" name="email">
                  </div>
                <div class="mb-3">
                  <input type="password" class="form-control" id="password" placeholder="password" name="password">
                </div>
                <div class="text-center"><button type="submit" class="btn btn-color px-5 mb-5 w-100">Sign in</button></div>
                <div id="emailHelp" class="form-text text-center mb-5 text-dark">Already Have an Account ?
                    <a href="/login" class="text-dark fw-bold"> Log in here!</a>
                </div>
              </form>
            </div>
    
          
      </div>
</body>
</html><?php /**PATH D:\Belajar Mandiri\Laravel\Leony\resources\views/register.blade.php ENDPATH**/ ?>