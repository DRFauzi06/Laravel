<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leony's Blog</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-dc2NSrAXbAkjrdm9IYrX10fQq9SDG6Vjz7nQVKdKcJl3pC+k37e7qJR5MVSCS+wR" crossorigin="anonymous">
    

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
</head>
<body>
    <!-- partial:index.partial.html -->
<section class="section-products">
    <div class="container">
            <div class="row justify-content-center text-center">
                    <div class="col-md-8 col-lg-6">
                            <div class="header">
                                    <h3>Leony Collection</h3>
                                    <h2>Popular Products</h2>
                            </div>
                    </div>
            </div>
            
                
            
            <div class="row">
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baju): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Single Product -->
                    <div class="col-md-6 col-lg-4 col-xl-3">
                            <div id="product-1" class="single-product">
                                <div class="card shadow  " style="width: 18rem;">
                                    <img src="fotoBaju/<?php echo e($baju->foto); ?>" class="card-img-top " alt="Gamis">
                                    
                                        
                                            
                                    </div>
                                    <div class="part-2">
                                            <h3 class="product-title">
                                                <?php if($baju->kodeBaju ==="G01"): ?>
                        <?php echo e($result[0]['jenisBaju']); ?>

                    <?php elseif($baju->kodeBaju ==="O02"): ?>
                    <?php echo e($result[1]['jenisBaju']); ?>

                    <?php elseif($baju->kodeBaju ==="H03"): ?>
                    <?php echo e($result[2]['jenisBaju']); ?>

                    <?php elseif($baju->kodeBaju ==="A04"): ?>
                    <?php echo e($result[3]['jenisBaju']); ?>

                    <?php endif; ?>
                                            </h3>
                                            <h4 class="product-price"><?php echo e($baju->ukuran); ?></h4>
                                            <br>
                                            <h4 class="product-price">Stok : <?php echo e($baju->jumlah); ?></h4>
                                            
                                            
                                    </div>
                            </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
            </div>
            
</section>
<!-- partial -->
    
</body>
</html><?php /**PATH D:\Belajar Mandiri\Laravel\Leony\resources\views/posts.blade.php ENDPATH**/ ?>