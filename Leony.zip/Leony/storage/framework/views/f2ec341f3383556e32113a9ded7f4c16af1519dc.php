<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="/">Leony's Blog</a>
      
      <div class="row">
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link " href="/">Home</a>
          </li>
          
          <li class="nav-item " >
            <a class="nav-link " href="/posts">Posts</a>
          </li>
        
              
          <?php if(auth()->user()): ?>

          <?php if(auth()->user()->level=="admin"): ?>
            <li class="nav-item " >
            <a class="nav-link " href="/baju">Data</a>
            </li>
            <?php endif; ?>
              
          <?php endif; ?>

            
              

          

          
            
        </ul>
        <ul class="navbar-nav">
          <li class="nav-item">
            <?php if(auth()->user()): ?>
            <a class="nav-link " href="/logout"><i class="bi bi-box-arrow-in-right"></i> Logout</a>
            <?php else: ?>
            <a class="nav-link " href="/login"><i class="bi bi-box-arrow-in-right"></i> Login</a>

            <?php endif; ?>
          
        </li>
        </ul>
      </div>
    </div>
  </div>
  </nav><?php /**PATH D:\Belajar Mandiri\Laravel\Leony\resources\views/partials/navbar.blade.php ENDPATH**/ ?>