<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KodeController extends Controller
{
    //
}
